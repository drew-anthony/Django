from django.shortcuts import render, redirect, reverse
from django.contrib import messages
from .models import *



def index(req):
    return render(req, 'index.html', {'users': User.objects.all()})

def registration(req):
    print('check1')

    if req.method == 'POST':
        errors = User.objects.validate(req.POST)
        if not errors:            
            user = User.objects.create_user(req.POST)            
            req.session['user_id'] = user.id
        if errors:
            for key, value in errors.items():
                print(messages.error(req,value))
                print(errors.items)

        return render(req, 'index.html')     
            
def login(req):
    errors = User.objects.validateLogin(req.POST)
    if len(errors):
        for key, value in errors.items():
            messages.error(req, value)
        return redirect('/')
    else:
        username = User.objects.get(email = req.POST['email']).first_name
        user_id = User.objects.get(email = req.POST['email']).id
        req.session['user_id'] = user_id
        print(req.session['user_id'])
        req.session['user'] = username
        return redirect('/wall')

def mainMessage(req):
    errors = Message.objects.validateMessage(req.POST)
    if len(errors):
        for key, value in errors.items():
            messages.error(req, value)
        return redirect('/wall')
    else:
        message = Message.objects.create_message(req.POST)
        return redirect('/wall')

def mainComment(req):
    errors = Comment.objects.validateComment(req.POST)
    if len(errors):
        for key, value in errors.items():
            messages.error(req, value)
        return redirect('/wall')
    else:
        comment = Comment.objects.create_comment(req.POST)
        return redirect('/wall')

def wall(req):
    context ={
        'wallPost': Message.objects.all(),
        'wallComment': Comment.objects.all(),
        'Posts': Message.objects.order_by('-created_at')
    }
    return render(req, 'wall.html', context)

def logout(req):
    return render(req,'logout.html')