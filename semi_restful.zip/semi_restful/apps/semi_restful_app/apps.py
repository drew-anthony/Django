from __future__ import unicode_literals

from django.apps import AppConfig


class SemiRestfulAppConfig(AppConfig):
    name = 'semi_restful_app'
