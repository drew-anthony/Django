from django.shortcuts import render, HttpResponse, redirect

def index(request):
    response = "placeholder for users to create a new user record"
    return redirect('blogs/')

def new(request):
    return redirect("users/")

def login(request):
    response = "placeholder for users to login"
    return HttpResponse(response)

def users(request,number):
    response = "placeholder to later display all the list of users"
    return HttpResponse(response)