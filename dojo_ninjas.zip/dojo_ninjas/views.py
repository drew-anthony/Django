from django.shortcuts import render, HttpResponse, redirect
from .models import *

def index(request):
    context = {
        "cars": Car.objects.all()   #{% for i in cars%} <h1>{{i.owner.first_name}}<h1> {% endfor %}
                                 #(%for x in i %)
    }
    pass
    
def process(request):

    return redirect("/")