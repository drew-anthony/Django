from __future__ import unicode_literals

from django.apps import AppConfig


class LikesBooksAppConfig(AppConfig):
    name = 'likes_books_app'
