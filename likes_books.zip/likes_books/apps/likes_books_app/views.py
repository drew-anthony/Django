from django.shortcuts import render, redirect, reverse

def index(request):
    return render(request, 'likes_books_app/index.html')
