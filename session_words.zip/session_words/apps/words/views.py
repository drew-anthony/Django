from django.shortcuts import render, HttpResponse, redirect
from time import gmtime, strftime

def index(request):
    if 'value' not in request.session:
        request.session['value'] = []
    return render(request, "words/index.html")

def process(request):
    showbig = 1 if 'big_font' in request.POST else 0
    temp = request.session['value']
    temp.append({'words': request.POST['word'], 'color': request.POST['color'], "time": strftime("%Y-%m-%d %H:%M %p", gmtime())})
    request.session['value'] = temp
    print(request.session['value'])
    return redirect('/')  

def reset(request):
    request.session.clear()
    return redirect('/')