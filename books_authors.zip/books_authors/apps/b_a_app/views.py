from django.shortcuts import render, redirect, reverse

def index(request):
    return render(request, 'b_a_app/index.html')
