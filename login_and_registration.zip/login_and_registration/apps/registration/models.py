from __future__ import unicode_literals
from django.db import models
import re
import bcrypt
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9+_-]+@[a-zA-z0-9+_-]+\.[a-zA-Z]+$')

class UserManager(models.Manager):
    def validate(self, postData):
        errors = {}
        if len(postData['first_name']) < 2:
            errors["first_name"] = "First Name must be longer than 2 charaters"
        if len(postData['last_name']) < 2:
            errors["last_name"] = 'Last Name must be longer than 2 characters'
        if len(postData['email']) < 8:
            errors["email"] = 'Email must be at least 8 characters long'
        elif not EMAIL_REGEX.match(postData['email']):
            errors['email'] = 'Email not in email format'
        if len(postData['password']) < 8:
            errors["password"] = "Password must be 8 characters long"
        if postData['confirm_password'] != postData['password']:
            errors['confirm_password'] = "Passwords do not match"
        return errors
        
    def create_user(self, postData):
        hash_pass = bcrypt.hashpw(postData['password'].encode(), bcrypt.gensalt())
        user = self.create(
            first_name = postData['first_name'],
            last_name = postData['last_name'],
            email = postData['email'],
            password = hash_pass,
        )
        return user

    def validateLogin(self, postData):
        errors = {}
        if User.objects.filter(email=postData['email']).exists():
            user = User.objects.get(email=postData['email'])
            if not bcrypt.checkpw(postData['password'].encode(), user.password.encode()):
                errors['password'] = 'E-mail password combination is incorrect.'
        else:
            errors['mail'] = 'E-mail password combination is incorrect.'
        return errors            

class User(models.Model):
    first_name = models.CharField(max_length=255)
    last_name = models.CharField(max_length=255)
    email = models.CharField(max_length=255)
    password = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    objects = UserManager()

    def __str__(self):
        return "{} - {}".format(self.id, self.email)