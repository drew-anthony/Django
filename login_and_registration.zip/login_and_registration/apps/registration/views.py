from django.shortcuts import render, redirect, reverse
from django.contrib import messages
from .models import *



def index(req):
    return render(req, 'index.html', {'users': User.objects.all()})

def registration(req):
    print('check1')

    if req.method == 'POST':
        errors = User.objects.validate(req.POST)
        if not errors:            
            user = User.objects.create_user(req.POST)            
            req.session['user_id'] = user.id
        if errors:
            for key, value in errors.items():
                print(messages.error(req,value))
                print(errors.items)

        return render(req, 'index.html')     
            
def login(req):
    errors = User.objects.validateLogin(req.POST)
    if len(errors):
        for key, value in errors.items():
            messages.error(req, value)
        return redirect('/')
    else:
        # username = User.objects.get(email = req.POST['email']).first_name
        # user_id = User.objects.get(email = req.POST['email']).id
        # req.session['user_id'] = user_id
        # req.session['user'] = username
        return render(req,'login.html')

def logout(req):
    return render(req,'logout.html')

    


       