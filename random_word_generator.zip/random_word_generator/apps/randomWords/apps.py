from django.apps import AppConfig


class RandomwordsConfig(AppConfig):
    name = 'randomWords'
