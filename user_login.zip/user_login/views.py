from django.shortcuts import render, HttpResponse, redirect

def index(request):
    response = "placeholder for users to create a new user record"
    return redirect('blogs/')